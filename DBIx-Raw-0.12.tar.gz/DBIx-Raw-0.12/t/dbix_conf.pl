{ 
	dsn => 'dbi:SQLite:dbname=:memory:', 
	user => 'root', 
	password => '',
}
